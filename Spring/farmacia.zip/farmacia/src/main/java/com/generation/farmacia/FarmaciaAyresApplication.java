package com.generation.farmacia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmaciaAyresApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmaciaAyresApplication.class, args);
	}

}
